#!/system/bin/sh

# cp /root/resolv.conf /etc/resolv.conf
# cp /root/head  /etc/resolvconf/resolv.conf.d/
